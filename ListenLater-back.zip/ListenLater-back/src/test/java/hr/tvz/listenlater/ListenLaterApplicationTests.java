package hr.tvz.listenlater;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListenLaterApplicationTests {

    @Test
    void contextLoads() {
    }

}
