package hr.tvz.listenlater.repository;

import hr.tvz.listenlater.model.Album;
import hr.tvz.listenlater.model.AppUser;
import hr.tvz.listenlater.model.SavedAlbum;
import hr.tvz.listenlater.model.enums.Action;
import lombok.AllArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
@AllArgsConstructor
public class SavedAlbumRepository {

    private final JdbcTemplate jdbc;
    private final NamedParameterJdbcTemplate jdbcParams;
    private final UserRepository userRepository;
    private final AlbumRepository albumRepository;

    public List<SavedAlbum> getAlbumsByUserId(Long userId) {
        String sql = " SELECT * FROM ALBUMS a " +
                " JOIN SAVED_ALBUMS sa ON a.ID = sa.ALBUM_ID " +
                " JOIN USERS u ON sa.USER_ID = u.ID " +
                " WHERE u.ID = :userId ";
        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue("userId", userId);

        return jdbcParams.query(sql, parameters, this::mapRowToSavedAlbum);
    }

    private SavedAlbum mapRowToSavedAlbum(ResultSet rs, int rowNum) throws SQLException {
        SavedAlbum savedAlbum = new SavedAlbum();

        Long userId = rs.getLong("USER_ID");
        Long albumId = rs.getLong("ALBUM_ID");

        savedAlbum.setAction(Action.valueOf(rs.getString("ACTION")));

        Timestamp timestamp = rs.getTimestamp("DATE_ADDED");
        if (timestamp != null) {
            savedAlbum.setDateAdded(timestamp.toInstant());
        }

        Optional<AppUser> optionalUser = userRepository.getEntityById(userId);
        if (optionalUser.isPresent()) {
            savedAlbum.setUser(optionalUser.get());
        }

        Optional<Album> optionalAlbum = albumRepository.getEntityById(albumId);
        if (optionalAlbum.isPresent()) {
            savedAlbum.setAlbum(optionalAlbum.get());
        }

        savedAlbum.setUserId(userId);
        savedAlbum.setAlbumId(albumId);

        return savedAlbum;
    }
}