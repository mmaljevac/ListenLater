package hr.tvz.listenlater.model.dto;

import lombok.Data;

@Data
public class RoleDTO {
    private String role;
}
