package hr.tvz.listenlater;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ListenLaterApplication {

    public static void main(String[] args) {
        SpringApplication.run(ListenLaterApplication.class, args);
    }

}
