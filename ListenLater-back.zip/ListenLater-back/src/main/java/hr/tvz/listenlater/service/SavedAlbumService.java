package hr.tvz.listenlater.service;

import hr.tvz.listenlater.model.SavedAlbum;
import hr.tvz.listenlater.model.response.CustomResponse;
import hr.tvz.listenlater.repository.SavedAlbumRepository;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class SavedAlbumService {

    private final SavedAlbumRepository savedAlbumRepository;

    public ResponseEntity<CustomResponse<Object>> getAlbumsByUserId(Long userId) {
        CustomResponse<Object> response;

        List<SavedAlbum> albumsByUser = savedAlbumRepository.getAlbumsByUserId(userId);

        response = CustomResponse.builder()
                .success(true)
                .message("Success getting data.")
                .data(albumsByUser)
                .build();
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
}