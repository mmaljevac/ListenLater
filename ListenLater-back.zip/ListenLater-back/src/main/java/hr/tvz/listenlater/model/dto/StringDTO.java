package hr.tvz.listenlater.model.dto;

import lombok.Data;

@Data
public class StringDTO {
    private String string;
}
