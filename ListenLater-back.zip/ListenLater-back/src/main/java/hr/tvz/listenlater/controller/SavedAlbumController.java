package hr.tvz.listenlater.controller;

import hr.tvz.listenlater.model.response.CustomResponse;
import hr.tvz.listenlater.service.SavedAlbumService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/saved-albums")
@AllArgsConstructor()
public class SavedAlbumController {

    private final SavedAlbumService savedAlbumService;

    @GetMapping("/user/{userId}")
    public ResponseEntity<CustomResponse<Object>> getAlbumsByUserId(@PathVariable Long userId) {
        return savedAlbumService.getAlbumsByUserId(userId);
    }

}