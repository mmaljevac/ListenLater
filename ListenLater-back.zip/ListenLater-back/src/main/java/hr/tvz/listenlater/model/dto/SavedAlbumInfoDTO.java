package hr.tvz.listenlater.model.dto;

import hr.tvz.listenlater.model.enums.Action;
import lombok.Data;

import java.time.Instant;

@Data
public class SavedAlbumInfoDTO {
    private Long albumId;
    private String name;
    private String artist;
    private String fullName;
    private String imgUrl;
    private Action action;
    private Instant dateAdded;
}
